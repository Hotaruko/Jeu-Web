Thanks for downloading these sprites from Gamedevtuts+! 

These sprites were designed by Jacob Zinman-Jeanes (http://jeanes.co) for Gamedevtuts+ (http://gamedev.tutsplus.com/).

To find out more about what's in this mini sprite pack, check out this post: http://gamedev.tutsplus.com/articles/news/enjoy-these-totally-free-space-based-shoot-em-up-sprites/

These sprites are licensed under the CC BY 3.0 license: http://creativecommons.org/licenses/by/3.0/
We require attribution, and a link to the aforementioned info post, from anyone that redistributes the artwork, but we do not require attribution if you use the art in your games (regardless of whether it is for commercial or personal use, or for a prototype or final product).

Any questions? Email gamedev@tutsplus.com.